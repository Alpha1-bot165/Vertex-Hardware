import React, { useState, useEffect } from 'react';
import { X, Minus, Plus, ShoppingBag, Trash2, ArrowLeft, CheckCircle, CreditCard } from 'lucide-react';
import { useCart } from './CartContext';

const CartModal = () => {
  const { isCartOpen, setIsCartOpen, cartItems, updateQuantity, removeFromCart, clearCart } = useCart();
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (!isCartOpen) {
      const timer = setTimeout(() => setStep('cart'), 300);
      return () => clearTimeout(timer);
    }
  }, [isCartOpen]);

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => {
      // Extract the first number from the price string (e.g., "RWF 12,500 - RWF 15,000 / Piece" -> "12500")
      const match = item.product.price.match(/[\d,]+/);
      let numericPrice = 0;
      if (match && match[0]) {
        numericPrice = parseFloat(match[0].replace(/,/g, ''));
      }
      return total + (numericPrice * item.quantity);
    }, 0);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setStep('success');
      clearCart();
    }, 1500);
  };

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      {/* Slide-over panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            {step === 'checkout' ? (
              <button 
                onClick={() => setStep('cart')}
                className="p-1 -ml-1 text-gray-400 hover:text-gray-600 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : (
              <ShoppingBag className="w-5 h-5 text-gray-900" />
            )}
            <h2 className="text-lg font-bold text-gray-900">
              {step === 'cart' && 'Your Cart'}
              {step === 'checkout' && 'Checkout'}
              {step === 'success' && 'Order Complete'}
            </h2>
            {step === 'cart' && (
              <span className="bg-orange-100 text-orange-600 text-xs font-bold px-2 py-0.5 rounded-full">
                {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'}
              </span>
            )}
          </div>
          <button 
            onClick={() => setIsCartOpen(false)}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {step === 'cart' && (
            <div className="space-y-4 h-full">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-4">
                  <ShoppingBag className="w-16 h-16 text-gray-200" />
                  <p className="text-lg font-medium">Your cart is empty</p>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="text-orange-500 hover:text-orange-600 font-medium"
                  >
                    Continue Shopping
                  </button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div key={item.product.id} className="flex gap-4 bg-white border border-gray-100 p-3 rounded-lg shadow-sm">
                    <div className="w-20 h-20 bg-gray-50 rounded-md overflow-hidden flex-shrink-0 border border-gray-100">
                      <img 
                        src={item.product.image} 
                        alt={item.product.name} 
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    
                    <div className="flex flex-col flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-gray-900 line-clamp-2 mb-1">
                        {item.product.name}
                      </h3>
                      <div className="text-xs text-gray-500 mb-2">{item.product.supplier}</div>
                      
                      <div className="text-sm font-bold text-orange-600 mb-2">
                        RWF {(() => {
                          const match = item.product.price.match(/[\d,]+/);
                          const price = match && match[0] ? parseFloat(match[0].replace(/,/g, '')) : 0;
                          return (price * item.quantity).toLocaleString();
                        })()}
                      </div>
                      
                      <div className="mt-auto flex items-center justify-between">
                        <div className="flex items-center border border-gray-200 rounded-md bg-gray-50">
                          <button 
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-l-md transition-colors"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="w-8 text-center text-sm font-medium text-gray-900">
                            {item.quantity}
                          </span>
                          <button 
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-r-md transition-colors"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        
                        <button 
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {step === 'checkout' && (
            <form id="checkout-form" onSubmit={handleCheckoutSubmit} className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-gray-900 mb-3">Shipping Information</h3>
                <div className="space-y-3">
                  <input required type="text" placeholder="Full Name" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  <input required type="email" placeholder="Email Address" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  <input required type="text" placeholder="Shipping Address" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  <div className="grid grid-cols-2 gap-3">
                    <input required type="text" placeholder="City" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                    <input required type="text" placeholder="Postal Code" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-gray-900 mb-3">Payment Details</h3>
                <div className="space-y-3">
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input required type="text" placeholder="Card Number" className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <input required type="text" placeholder="MM/YY" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                    <input required type="text" placeholder="CVC" className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm" />
                  </div>
                </div>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-green-500 mb-2">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">Payment Successful!</h3>
              <p className="text-gray-500 max-w-[250px]">
                Thank you for your order. We've sent a confirmation email with your order details.
              </p>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="mt-8 bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-lg transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        {step === 'cart' && cartItems.length > 0 && (
          <div className="border-t border-gray-100 p-4 bg-gray-50">
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-600 font-medium">Estimated Total</span>
              <span className="text-lg font-bold text-gray-900">
                RWF {calculateTotal().toLocaleString()}
              </span>
            </div>
            <button 
              onClick={() => setStep('checkout')}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              Proceed to Checkout
            </button>
          </div>
        )}

        {step === 'checkout' && (
          <div className="border-t border-gray-100 p-4 bg-gray-50">
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-600 font-medium">Total to Pay</span>
              <span className="text-lg font-bold text-gray-900">
                RWF {calculateTotal().toLocaleString()}
              </span>
            </div>
            <button 
              type="submit"
              form="checkout-form"
              disabled={isProcessing}
              className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              {isProcessing ? 'Processing...' : 'Pay Now'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartModal;
