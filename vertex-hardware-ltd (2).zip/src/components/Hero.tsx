import React from 'react';
import { ChevronRight, Square, Circle, Columns, Layers, AlignLeft, ShieldCheck, Grid, HardHat, Wrench, Truck } from 'lucide-react';

const categories = [
  { name: 'Square & Rect Tubings', icon: <Square className="w-4 h-4" /> },
  { name: 'Round Tubings & Pipes', icon: <Circle className="w-4 h-4" /> },
  { name: 'U Channels & C Channels', icon: <Columns className="w-4 h-4" /> },
  { name: 'MS Sheets & Plates', icon: <Layers className="w-4 h-4" /> },
  { name: 'Angle Lines & Bars', icon: <AlignLeft className="w-4 h-4" /> },
  { name: 'Galvanized Steel', icon: <ShieldCheck className="w-4 h-4" /> },
  { name: 'Structural Beams', icon: <Grid className="w-4 h-4" /> },
  { name: 'Building Materials', icon: <HardHat className="w-4 h-4" /> },
  { name: 'Fasteners & Hardware', icon: <Wrench className="w-4 h-4" /> },
  { name: 'Logistics & Shipping', icon: <Truck className="w-4 h-4" /> },
];

const Hero = () => {
  return (
    <section className="flex gap-6 h-[480px]">
      {/* Sidebar Categories */}
      <div className="w-64 bg-white rounded-xl shadow-sm border border-gray-100 hidden lg:flex flex-col py-3 overflow-hidden">
        <h3 className="px-4 pb-2 font-bold text-gray-900 border-b border-gray-100 mb-2">My Markets</h3>
        <ul className="flex-1 overflow-y-auto">
          {categories.map((cat, idx) => (
            <li key={idx} className="group px-4 py-2.5 hover:bg-orange-50 cursor-pointer flex items-center justify-between transition-colors">
              <div className="flex items-center gap-3 text-sm text-gray-700 group-hover:text-orange-600 font-medium">
                <span className="text-gray-400 group-hover:text-orange-500">{cat.icon}</span>
                {cat.name}
              </div>
              <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-orange-500" />
            </li>
          ))}
        </ul>
      </div>

      {/* Main Banner */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden relative group">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
          alt="Hardware Warehouse" 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 z-20 flex flex-col justify-center px-12 max-w-2xl">
          <span className="inline-block px-3 py-1 bg-orange-500 text-white text-xs font-bold uppercase tracking-wider rounded-full mb-4 w-max">Global Sourcing Event</span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white leading-tight mb-4">
            Source Premium <br/>
            <span className="text-orange-400">Hardware Supplies</span>
          </h1>
          <p className="text-gray-200 text-lg mb-8 max-w-md">
            Connect with verified manufacturers. Get up to 50% off on bulk orders for construction and industrial projects.
          </p>
          <div className="flex gap-4">
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-full font-bold transition-all transform hover:-translate-y-0.5 shadow-lg hover:shadow-orange-500/30">
              Source Now
            </button>
            <button className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-8 py-3 rounded-full font-bold transition-all">
              View Deals
            </button>
          </div>
        </div>
      </div>

      {/* Right Sidebar (Promos/User) */}
      <div className="w-72 hidden xl:flex flex-col gap-4">
        {/* User Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-2xl mb-3 shadow-inner">
            V
          </div>
          <h4 className="font-bold text-gray-900 mb-1">Welcome to Vertex</h4>
          <p className="text-xs text-gray-500 mb-4">Sign in to enjoy personalized sourcing and exclusive deals.</p>
          <div className="flex gap-2 w-full">
            <button className="flex-1 bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold py-2 rounded-full transition-colors">Join Free</button>
            <button className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 text-sm font-bold py-2 rounded-full transition-colors">Sign In</button>
          </div>
        </div>

        {/* Promo Banner */}
        <div className="flex-1 bg-gradient-to-br from-blue-900 to-indigo-900 rounded-xl shadow-sm p-5 relative overflow-hidden group cursor-pointer">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-2xl"></div>
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div>
              <span className="text-blue-200 text-xs font-bold uppercase tracking-wider">Trade Assurance</span>
              <h4 className="text-white font-bold text-lg leading-tight mt-1">Protect your orders from payment to delivery</h4>
            </div>
            <div className="flex items-center text-blue-300 text-sm font-medium group-hover:text-white transition-colors mt-4">
              Learn more <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
