import React, { useState } from 'react';
import { Search, ShoppingCart, User, MessageSquare, Menu, ChevronDown, Smartphone, X } from 'lucide-react';
import { useAuth } from './AuthContext';
import { useCart } from './CartContext';

const Header = ({ searchQuery = '', setSearchQuery = (q: string) => {} }: { searchQuery?: string, setSearchQuery?: (q: string) => void }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, openAuthModal, logout } = useAuth();
  const { cartCount, setIsCartOpen } = useCart();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 relative">
      {/* Main Header */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex-shrink-0 flex items-center">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="mr-4 lg:hidden p-1 text-gray-600 hover:text-orange-500 hover:bg-orange-50 rounded-md transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
          <a href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold text-xl">V</div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-gray-900 leading-none tracking-tight">VERTEX</span>
              <span className="text-[10px] font-semibold text-orange-500 uppercase tracking-widest">Hardware Ltd</span>
            </div>
          </a>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-3xl hidden md:flex">
          <div className="flex w-full border-2 border-orange-500 rounded-full overflow-hidden focus-within:ring-2 focus-within:ring-orange-200 transition-all">
            <div className="relative hidden lg:block">
              <select className="appearance-none bg-gray-50 border-r border-gray-200 py-2.5 pl-4 pr-8 text-sm text-gray-700 focus:outline-none cursor-pointer h-full">
                <option>Products</option>
                <option>Suppliers</option>
              </select>
              <ChevronDown className="w-4 h-4 text-gray-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
            <input 
              type="text" 
              placeholder="What are you looking for..." 
              className="flex-1 py-2.5 px-4 text-sm focus:outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-2.5 font-medium transition-colors flex items-center gap-2">
              <Search className="w-4 h-4" />
              Search
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-6 text-gray-600">
          {user ? (
            <div 
              className="flex flex-col items-center cursor-pointer hover:text-orange-500 group"
              onClick={logout}
              title="Click to sign out"
            >
              <div className="w-8 h-8 mb-1 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center text-sm font-bold">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <span className="text-[11px] font-medium truncate max-w-[60px]">Sign Out</span>
            </div>
          ) : (
            <div 
              className="flex flex-col items-center cursor-pointer hover:text-orange-500 group"
              onClick={openAuthModal}
            >
              <User className="w-5 h-5 mb-1 group-hover:fill-orange-50" />
              <span className="text-[11px] font-medium">Sign In</span>
            </div>
          )}
          <div className="flex flex-col items-center cursor-pointer hover:text-orange-500 group hidden sm:flex">
            <MessageSquare className="w-5 h-5 mb-1 group-hover:fill-orange-50" />
            <span className="text-[11px] font-medium">Messages</span>
          </div>
          <div 
            className="flex flex-col items-center cursor-pointer hover:text-orange-500 group hidden sm:flex"
            onClick={() => setIsCartOpen(true)}
          >
            <div className="relative">
              <ShoppingCart className="w-5 h-5 mb-1 group-hover:fill-orange-50" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="text-[11px] font-medium">Cart</span>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="border-t border-gray-100 hidden lg:block">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-12">
          <div className="flex items-center gap-2 font-medium text-sm cursor-pointer hover:text-orange-500 pr-8 border-r border-gray-200 h-full">
            <Menu className="w-5 h-5" />
            All Categories
          </div>
          <nav className="flex items-center space-x-8 pl-8 text-sm font-medium text-gray-700">
            <a href="#" className="hover:text-orange-500 transition-colors">Ready to Ship</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Personal Protective Equipment</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Trade Assurance</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Dropshipping</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Global Sources</a>
          </nav>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-[100] flex">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
            onClick={() => setIsMenuOpen(false)}
          />
          {/* Drawer */}
          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-left duration-300">
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <span className="font-bold text-lg text-gray-900">Menu</span>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex flex-col p-4 gap-4 text-sm font-medium text-gray-700 overflow-y-auto">
              <a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2 pb-4 border-b border-gray-100">
                <Menu className="w-4 h-4" /> All Categories
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors py-2">Ready to Ship</a>
              <a href="#" className="hover:text-orange-500 transition-colors py-2">Personal Protective Equipment</a>
              <a href="#" className="hover:text-orange-500 transition-colors py-2">Trade Assurance</a>
              <a href="#" className="hover:text-orange-500 transition-colors py-2">Dropshipping</a>
              <a href="#" className="hover:text-orange-500 transition-colors py-2">Global Sources</a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
