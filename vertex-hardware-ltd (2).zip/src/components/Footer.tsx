import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, Youtube, Mail, Phone, MapPin, Globe, Smartphone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold text-xl">V</div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-white leading-none tracking-tight">VERTEX</span>
                <span className="text-[10px] font-semibold text-orange-500 uppercase tracking-widest">Hardware Ltd</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-6 max-w-sm leading-relaxed">
              Your trusted global B2C sourcing platform for premium hardware, tools, and industrial supplies. Connecting verified manufacturers with buyers worldwide.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"><Twitter className="w-4 h-4" /></a>
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"><Linkedin className="w-4 h-4" /></a>
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"><Youtube className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Customer Services */}
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Customer Services</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-orange-500 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Report Abuse</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Submit a Dispute</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Policies & Rules</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Get Paid for Your Feedback</a></li>
            </ul>
          </div>

          {/* About Us */}
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">About Us</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-orange-500 transition-colors">About Vertex Hardware</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">About Vertex Group</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Sitemap</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Blog</a></li>
              <li className="pt-4 mt-4 border-t border-gray-800">
                <span className="block text-xs text-gray-500 mb-1">CEO & Founder</span>
                <span className="block text-gray-300 font-medium">ISHIMWE ELIE</span>
                <a href="tel:+250784500782" className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mt-2 transition-colors">
                  <Phone className="w-3 h-3" />
                  +250 784 500 782
                </a>
              </li>
            </ul>
          </div>

          {/* Source on Vertex */}
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Source on Vertex</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-orange-500 transition-colors">Resources</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">All Categories</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Request for Quotation</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Ready to Ship</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Buyer Partners</a></li>
            </ul>
          </div>
        </div>

        {/* Settings & Preferences */}
        <div className="border-t border-gray-800 pt-8 pb-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-6">
            <span className="flex items-center cursor-pointer hover:text-white transition-colors"><Globe className="w-4 h-4 mr-2" /> English - RWF</span>
            <span className="flex items-center cursor-pointer hover:text-white transition-colors"><MapPin className="w-4 h-4 mr-2" /> Ship to: RW</span>
          </div>
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-6">
            <span className="cursor-pointer hover:text-white transition-colors">Buyer Central</span>
            <span className="cursor-pointer hover:text-white transition-colors">Help Center</span>
            <span className="flex items-center cursor-pointer hover:text-white transition-colors"><Smartphone className="w-4 h-4 mr-2" /> Get the App</span>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <div className="flex flex-wrap justify-center md:justify-start gap-4">
            <span className="text-gray-400 font-medium">Vertex Hardware Ltd</span>
            <span className="hidden md:inline text-gray-600">|</span>
            <span className="text-gray-500">Kigali, Rwanda</span>
          </div>
          <div className="text-center md:text-right">
            <p>&copy; {new Date().getFullYear()} Vertex Hardware Ltd. All rights reserved.</p>
            <div className="flex items-center justify-center md:justify-end gap-4 mt-2">
              <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
