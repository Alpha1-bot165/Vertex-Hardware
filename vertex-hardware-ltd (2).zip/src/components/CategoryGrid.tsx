import React from 'react';

const categories = [
  { name: 'Square Tubings', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Rezidual_Stress.JPG/500px-Rezidual_Stress.JPG' },
  { name: 'Round Tubings', image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80' },
  { name: 'U & C Channels', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/I-Beam_002.JPG/500px-I-Beam_002.JPG' },
  { name: 'MS Sheets', image: 'https://images.unsplash.com/photo-1534234538058-b671a5c1e5d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80' },
  { name: 'Angle Lines', image: 'https://shanangagroup.co.tz/wp-content/uploads/2024/03/ANGLE-LINE.png' },
  { name: 'Rectangular Tubes', image: 'https://steeloncall.com/media/catalog/product/cache/1/small_image/450x/17f82f742ffe127f42dca9de82fb58b1/3/2/32fwmgqa_2_4.png' },
  { name: 'Galvanized Steel', image: 'https://images.unsplash.com/photo-1501166222995-ff41c7e50859?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80' },
  { name: 'Steel Beams', image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80' },
];

const CategoryGrid = ({ onCategoryClick }: { onCategoryClick?: (category: string) => void }) => {
  return (
    <section className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Source by Category</h2>
        <a href="#" className="text-orange-500 hover:text-orange-600 font-medium text-sm">View All Categories</a>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {categories.map((cat, idx) => (
          <div 
            key={idx} 
            className="group cursor-pointer flex flex-col items-center text-center"
            onClick={() => {
              if (onCategoryClick) {
                // Use a generic search term based on the category to ensure it finds products
                const searchTerm = cat.name.split(' ')[0]; // e.g., "Square" from "Square Tubings"
                onCategoryClick(searchTerm);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
          >
            <div className="w-24 h-24 rounded-full bg-gray-50 border border-gray-100 overflow-hidden mb-3 group-hover:border-orange-500 group-hover:shadow-md transition-all p-2">
              <div className="w-full h-full rounded-full overflow-hidden bg-white">
                <img 
                  src={cat.image} 
                  alt={cat.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <span className="text-sm font-medium text-gray-700 group-hover:text-orange-600 transition-colors line-clamp-2 leading-tight">
              {cat.name}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
};

export default CategoryGrid;
