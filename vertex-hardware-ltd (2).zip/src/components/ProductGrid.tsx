import React from 'react';
import { Star, ShoppingCart, Heart, ShieldCheck } from 'lucide-react';
import { useCart } from './CartContext';

const products = [
  {
    id: 1,
    name: 'Mild Steel Square Tubing 50x50x2.0mm - 6M Length',
    price: 'RWF 12,500 - RWF 15,000 / Piece',
    minOrder: '50 Pieces',
    rating: 4.8,
    reviews: 124,
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Rezidual_Stress.JPG/500px-Rezidual_Stress.JPG',
    supplier: 'Vertex Steel Mills Co., Ltd.',
    verified: true,
  },
  {
    id: 2,
    name: 'Hot Rolled Steel U Channel 100x50x5.0mm Structural Profile',
    price: 'RWF 28,000 - RWF 32,200 / Piece',
    minOrder: '20 Pieces',
    rating: 4.9,
    reviews: 89,
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/I-Beam_002.JPG/500px-I-Beam_002.JPG',
    supplier: 'Global Metal Profiles Mfg.',
    verified: true,
  },
  {
    id: 3,
    name: 'MS Sheet / Mild Steel Plate 1220x2440x3.0mm (4x8 ft)',
    price: 'RWF 45,000 - RWF 55,500 / Piece',
    minOrder: '10 Pieces',
    rating: 4.7,
    reviews: 210,
    image: 'https://images.unsplash.com/photo-1534234538058-b671a5c1e5d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
    supplier: 'Precision Steel Plates Ltd.',
    verified: false,
  },
  {
    id: 4,
    name: 'Galvanized Round Steel Tubing OD 48.3mm x 3.2mm Scaffold Pipe',
    price: 'RWF 18,500 - RWF 22,000 / Piece',
    minOrder: '100 Pieces',
    rating: 4.6,
    reviews: 56,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
    supplier: 'ElectroTech Tubes',
    verified: true,
  },
  {
    id: 5,
    name: 'Equal Steel Angle Iron / Angle Line 40x40x4.0mm - 6M',
    price: 'RWF 9,200 - RWF 11,500 / Piece',
    minOrder: '100 Pieces',
    rating: 4.5,
    reviews: 342,
    image: 'https://shanangagroup.co.tz/wp-content/uploads/2024/03/ANGLE-LINE.png',
    supplier: 'SafeGuard Structural',
    verified: true,
  },
  {
    id: 6,
    name: 'Rectangular Steel Tubing 80x40x3.0mm Hollow Section',
    price: 'RWF 16,000 - RWF 19,000 / Piece',
    minOrder: '50 Pieces',
    rating: 4.8,
    reviews: 178,
    image: 'https://steeloncall.com/media/catalog/product/cache/1/small_image/450x/17f82f742ffe127f42dca9de82fb58b1/3/2/32fwmgqa_2_4.png',
    supplier: 'Vertex Metal Tubes',
    verified: true,
  },
  {
    id: 7,
    name: 'Cold Rolled MS Sheet 1000x2000x1.5mm Carbon Steel',
    price: 'RWF 22,500 - RWF 26,000 / Piece',
    minOrder: '20 Pieces',
    rating: 4.4,
    reviews: 45,
    image: 'https://images.unsplash.com/photo-1501166222995-ff41c7e50859?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
    supplier: 'Prime Steel Co.',
    verified: false,
  },
  {
    id: 8,
    name: 'Heavy Duty C Channel 150x75x6.5mm Structural Steel Beam',
    price: 'RWF 65,000 - RWF 72,000 / Piece',
    minOrder: '10 Pieces',
    rating: 4.9,
    reviews: 312,
    image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
    supplier: 'IronLink Beams',
    verified: true,
  },
];

const ProductGrid = ({ title, searchQuery = '' }: { title: string, searchQuery?: string }) => {
  const { addToCart } = useCart();
  
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.supplier.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (searchQuery && filteredProducts.length === 0) {
    return (
      <section className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">No results found</h2>
        <p className="text-gray-500">We couldn't find any products matching "{searchQuery}"</p>
      </section>
    );
  }

  return (
    <section className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
        {!searchQuery && <a href="#" className="text-orange-500 hover:text-orange-600 font-medium text-sm">View More</a>}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <div 
            key={product.id} 
            className="group flex flex-col bg-white rounded-lg border border-gray-100 hover:border-orange-500 hover:shadow-lg transition-all duration-300 overflow-hidden relative cursor-pointer"
            onClick={() => window.location.href = 'tel:0784500782'}
          >
            {/* Wishlist Button */}
            <button 
              onClick={(e) => e.stopPropagation()}
              className="absolute top-3 right-3 z-10 p-1.5 bg-white/80 backdrop-blur-sm rounded-full text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
            >
              <Heart className="w-5 h-5" />
            </button>
            
            {/* Image */}
            <div className="aspect-square bg-gray-50 p-4 relative overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              {product.verified && (
                <div className="absolute bottom-2 left-2 bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Verified
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="p-4 flex flex-col flex-1">
              <h3 className="text-sm text-gray-800 font-medium line-clamp-2 mb-2 group-hover:text-orange-600 transition-colors">
                {product.name}
              </h3>
              
              <div className="mt-auto">
                <div className="text-lg font-bold text-gray-900 mb-1">{product.price}</div>
                
                <div className="flex items-center gap-1 mb-3">
                  <Star className="w-3.5 h-3.5 fill-orange-400 text-orange-400" />
                  <span className="text-xs font-bold text-gray-700">{product.rating}</span>
                  <span className="text-xs text-gray-400">({product.reviews})</span>
                </div>
                
                <div className="text-xs text-gray-500 border-t border-gray-100 pt-3 line-clamp-1">
                  {product.supplier}
                </div>
              </div>
            </div>
            
            {/* Hover Actions */}
            <div className="absolute inset-x-0 bottom-0 bg-white border-t border-gray-100 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex gap-2">
              <a 
                href="tel:0784500782"
                onClick={(e) => e.stopPropagation()}
                className="flex-1 bg-orange-50 hover:bg-orange-100 text-orange-600 font-medium text-sm py-2 rounded transition-colors flex items-center justify-center"
              >
                Contact Supplier
              </a>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(product);
                }}
                className="w-10 flex items-center justify-center bg-gray-50 hover:bg-gray-100 text-gray-600 rounded transition-colors"
                title="Add to Cart"
              >
                <ShoppingCart className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProductGrid;
