import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CategoryGrid from './components/CategoryGrid';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';
import { AuthProvider } from './components/AuthContext';
import AuthModal from './components/AuthModal';
import { CartProvider } from './components/CartContext';
import CartModal from './components/CartModal';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <AuthProvider>
      <CartProvider>
        <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
          <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
          <main className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-10">
            {!searchQuery && <Hero />}
            {!searchQuery && <CategoryGrid onCategoryClick={setSearchQuery} />}
            <ProductGrid title={searchQuery ? "Search Results" : "New Arrivals"} searchQuery={searchQuery} />
            {!searchQuery && <ProductGrid title="Just For You" />}
          </main>
          <Footer />
          <AuthModal />
          <CartModal />
        </div>
      </CartProvider>
    </AuthProvider>
  );
}
